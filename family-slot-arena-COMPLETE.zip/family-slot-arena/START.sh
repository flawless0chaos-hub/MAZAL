#!/bin/bash

echo ""
echo "===================================="
echo "   🎰 Family Slot Arena 🎰"
echo "===================================="
echo ""
echo "מתקין תלויות..."
npm install
echo ""
echo "מפעיל את השרת..."
echo ""
echo "================================"
echo "  המשחק מוכן!"
echo "  פתח בדפדפן: http://localhost:3000"
echo "================================"
echo ""
npm run dev
